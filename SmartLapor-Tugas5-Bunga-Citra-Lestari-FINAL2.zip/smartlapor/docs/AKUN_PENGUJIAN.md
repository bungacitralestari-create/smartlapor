# Akun Pengujian SmartLapor

Akun berikut hanya untuk **development/testing lokal** saat `SEED_DEV=true`.
Jangan gunakan password ini pada lingkungan produksi.

| Role | Email | Password |
|---|---|---|
| Admin | admin@smartlapor.local | Admin123! |
| Petugas | petugas1@smartlapor.local | Petugas123! |
| Masyarakat | warga1@smartlapor.local | Warga123! |
| Pimpinan | pimpinan@smartlapor.local | Pimpinan123! |

Untuk deployment/produksi, nonaktifkan `SEED_DEV` dan gunakan kredensial yang aman.
