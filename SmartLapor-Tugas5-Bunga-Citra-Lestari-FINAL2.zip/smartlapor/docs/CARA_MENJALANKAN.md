# Cara Menjalankan SmartLapor Tugas 5

## Cara termudah: Docker Desktop
1. Install dan buka Docker Desktop.
2. Extract ZIP.
3. Buka folder `smartlapor`.
4. Double-click `START_WINDOWS.bat`.
5. Tunggu sampai terminal menunjukkan service berjalan.
6. Buka Chrome: http://localhost:5173
7. Login dengan akun warga:
   - Email: warga1@smartlapor.local
   - Password: Warga123!

Akun lain:
- Admin: admin@smartlapor.local / Admin123!
- Petugas: petugas1@smartlapor.local / Petugas123!
- Pimpinan: pimpinan@smartlapor.local / Pimpinan123!

## Jika login gagal
Pastikan halaman dibuka melalui `http://localhost:5173`, bukan file `index.html`.
Tunggu backend selesai start. Refresh halaman setelah service siap.

## Reset database
Double-click `RESET_DATABASE_WINDOWS.bat` jika ingin menghapus database dan membuat ulang akun seed.

## Stop aplikasi
Double-click `STOP_WINDOWS.bat`.
