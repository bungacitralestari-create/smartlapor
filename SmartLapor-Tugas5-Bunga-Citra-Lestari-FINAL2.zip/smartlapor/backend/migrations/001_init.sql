CREATE EXTENSION IF NOT EXISTS "pgcrypto";

DO $$ BEGIN
  CREATE TYPE user_role AS ENUM ('admin','petugas','masyarakat','pimpinan');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE report_status AS ENUM ('Diajukan','Diverifikasi','Ditugaskan','Diproses','Menunggu Verifikasi','Selesai','Ditolak');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE report_priority AS ENUM ('Mendesak','Tinggi','Sedang','Rendah');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS users (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL, email text UNIQUE NOT NULL,
 password_hash text NOT NULL, role user_role NOT NULL DEFAULT 'masyarakat', is_active boolean NOT NULL DEFAULT true,
 must_change_password boolean NOT NULL DEFAULT false, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS refresh_tokens (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 token_hash text UNIQUE NOT NULL, expires_at timestamptz NOT NULL, revoked_at timestamptz, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS categories (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text UNIQUE NOT NULL, description text, is_active boolean NOT NULL DEFAULT true,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS regions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), kecamatan text NOT NULL, kelurahan text NOT NULL, is_active boolean NOT NULL DEFAULT true,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), UNIQUE(kecamatan, kelurahan)
);
CREATE TABLE IF NOT EXISTS reports (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES users(id), category_id uuid NOT NULL REFERENCES categories(id), region_id uuid REFERENCES regions(id),
 title text NOT NULL CHECK (char_length(title) BETWEEN 5 AND 160), description text NOT NULL CHECK (char_length(description) BETWEEN 10 AND 5000),
 priority report_priority NOT NULL DEFAULT 'Sedang', latitude double precision NOT NULL CHECK (latitude BETWEEN -90 AND 90), longitude double precision NOT NULL CHECK (longitude BETWEEN -180 AND 180),
 address text NOT NULL, status report_status NOT NULL DEFAULT 'Diajukan', created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS report_attachments (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), report_id uuid NOT NULL REFERENCES reports(id) ON DELETE CASCADE, file_url text NOT NULL, file_type text NOT NULL, file_size bigint NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS assignments (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), report_id uuid NOT NULL REFERENCES reports(id) ON DELETE CASCADE, officer_id uuid NOT NULL REFERENCES users(id), assigned_by uuid NOT NULL REFERENCES users(id), assigned_at timestamptz NOT NULL DEFAULT now(), UNIQUE(report_id)
);
CREATE TABLE IF NOT EXISTS report_status_history (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), report_id uuid NOT NULL REFERENCES reports(id) ON DELETE CASCADE, old_status report_status, new_status report_status NOT NULL, changed_by uuid NOT NULL REFERENCES users(id), note text, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS resolution_evidence (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), report_id uuid NOT NULL REFERENCES reports(id) ON DELETE CASCADE, officer_id uuid NOT NULL REFERENCES users(id), description text NOT NULL, file_url text, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS audit_logs (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid REFERENCES users(id), action text NOT NULL, entity_type text, entity_id uuid, ip_address text, user_agent text, metadata jsonb, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status); CREATE INDEX IF NOT EXISTS idx_reports_category ON reports(category_id); CREATE INDEX IF NOT EXISTS idx_reports_region ON reports(region_id); CREATE INDEX IF NOT EXISTS idx_reports_user ON reports(user_id); CREATE INDEX IF NOT EXISTS idx_reports_created ON reports(created_at); CREATE INDEX IF NOT EXISTS idx_assignments_officer ON assignments(officer_id); CREATE INDEX IF NOT EXISTS idx_history_report ON report_status_history(report_id); CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
