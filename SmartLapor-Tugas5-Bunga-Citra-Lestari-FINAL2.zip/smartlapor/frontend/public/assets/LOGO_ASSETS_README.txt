ASSET LOGO RESMI
Sediakan logo resmi Pemerintah Daerah dan Universitas Teknokrat Indonesia pada folder ini sesuai arahan dosen/instansi.
Jangan menggunakan logo palsu. File dapat dinamai pemda-logo.png dan teknokrat-logo.png lalu ditampilkan pada kop/footer jika asset resmi tersedia.
